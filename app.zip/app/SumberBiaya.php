<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SumberBiaya extends Model
{
    //
}
