<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class KtpStatus extends Model
{
    //
    protected $table = "ktp_status";
}
