<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UnitInventaris extends Model
{
    protected $table = "unit";
}
