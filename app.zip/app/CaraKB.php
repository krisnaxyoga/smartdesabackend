<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CaraKB extends Model
{
    //
    protected $table = 'cara_kb';
}
