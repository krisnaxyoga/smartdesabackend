<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PendudukHubungan extends Model
{
    //
    protected $table = 'penduduk_hubungan';
}
